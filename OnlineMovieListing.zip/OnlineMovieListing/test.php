<?php 
////$url = "https://api.themoviedb.org/3/search/movie?api_key=fb28c6f143c808498e0f67cbb3d3caea&query=".$a;
// $url = str_replace(' ','%20',$url);


 $url="https://api.themoviedb.org/3/movie/10402?api_key=fb28c6f143c808498e0f67cbb3d3caea&language=en-US";
//$url = "https://api.themoviedb.org/3/discover/movie?api_key=fb28c6f143c808498e0f67cbb3d3caea&with_genres=12";

$ch = curl_init($url);
// var_dump($ch);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$result = curl_exec($ch);
$myData = json_decode($result,true);

print_r($myData);
echo '<br><br>';
echo $myData['poster_path'];
// echo '<br><br>';
// echo $myData['original_language'];
// echo '<br><br>';
// echo $myData['overview'];
// echo '<br><br>';
// echo $myData['poster_path'];
// echo '<br><br>';
// echo $myData['production_companies'][0]['name'];
// echo '<br><br>';
// echo $myData['production_countries'][0]['name'];
// echo '<br><br>';
// echo $myData['spoken_languages'][0]['name'];

 // [original_title]
 //  [original_language] 
 //  [overview]
 //   [poster_path] 
 //   [production_companies] -> [name] // multiple with index 0,1,2..
 //   [production_countries]  => Array -> [name]
 //   [spoken_languages] => Array -> [name]

/*echo "curl error".curl_error($ch);*/

curl_close($ch);
?>
