<?php
session_start();
// print_r($_SESSION);

$sessionUserName = $_SESSION['SESS_USER_NAME'];
$sessionUserEmail = $_SESSION['SESS_USER_EMAIL'];
$sessionUserID = $_SESSION['SESS_USER_ID'];
$sesionUserType = $_SESSION['SESS_USER_TYPE']; 

if(($sessionUserID == '' || $sessionUserID == 0) && $sessionUserEmail == '' && $sessionUserName == ''){
header("location: index.php?status=3");
exit;
}

include_once('classes/query_class.php');
$qc = new queryClass();

?>