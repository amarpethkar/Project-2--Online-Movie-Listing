<?php
include('auth.php');
// print_r($_SESSION);

$list = $qc->genreList();
//print_r($list);



?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Home Page | Online Movie Booking</title>
	 	<meta charset="utf-8">
	 	<meta name="	" content="width=device-width, initial-scale=1">
	 	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	 	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	 	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
	 	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
	 	<style>
			  /* Make the image fully responsive */
			  	.carousel-inner img {
			      width: 100%;
			      height: 100%;
			  }
			  .menuClass{
			  	margin-top: 0 !important;
				margin-bottom: 0px !important;
				height: 35px !important;
				padding: 5px !important;
				width: 100% !important;
			  }
			  .menuActive{
			  	background-color: #ccc;
			  }
  		</style>
	</head>
<body>

	<!-- Navbar  -->
	<div class="container-fluid">
			<nav class="navbar navbar-expand-lg navbar-light bg-light" style="width: 100%;">
				<a class="navbar-brand" href="home.php">Movie Listing</a>
				  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
				    <span class="navbar-toggler-icon"></span>
				  </button>
				<div class="collapse navbar-collapse" id="navbarTogglerDemo02">
				    <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
				    <li class="nav-item">
				        <a class="nav-link" href="logout.php">Logout</a>
				     </li>
				    </ul>
				    <span class="form-inline my-2 my-lg-0">
				      <input class="form-control mr-sm-2" type="search" placeholder="Search Movie" id="searchMovie">
				      <button class="btn btn-outline-success my-2 my-sm-0" type="button" onclick="searchInfo();">Search</button>
				    </span>
				</div>
			</nav>
	</div>
	<!-- Header-->
	<div class="jumbotron text-center">
  		<h1>Online Movie Listing</h1>
 		<p>Enjoy your day with entertainment !!!</p> 
	</div>

<div class="container">
      <div class="row">
		    <div class="col-sm-4">
		    	<br>
				<!-- select Genre -->
				<div class="row">
		    		<button type="button" class="btn btn-primary" data-toggle="collapse" data-target="#genre" style=" width: 100%;">Select Genre</button>
					<div id="genre" style="width: 100%; margin-top: 20px" class="collapse show">
					<?php
					for($i=0; $i<count($list);$i++){
						$css= "";
						if($i==0){
							//echo $list[$i]['id'];
							$movie = $qc->movieList($list[$i]['id']);
							$css = "menuActive";
						}

						?>
					    <div class="form-check">
						  <label class="form-check-label" style="width: 100%">
						  	<p class='menuClass <?php echo $css;?>' onClick="showMovieCart('<?php echo $list[$i]['id'] ;?>',this);" style="cursor:pointer;"> <?php echo $list[$i]['name'] ?> </p>
						  </label>
						</div>
						<?php } 
						//print_r($movie);
						?>
					</div>
				</div>
				<br>
				
		    </div>
		<!-- end of Col-md-4 -->
			<div class="col-sm-8">
				<!-- row  -->
		    	<div class="row" id='movieCart'>
		    		<!-- cart  -->
		    		<?php 
		    		$myData = $movie;
				   for($i=0;$i<count($myData);$i++){
		//echo $i;
		$searchData .= "<div class='col-sm-6' style='margin-bottom:30px'><div class='card' style='width:100%''><img class='card-img-top' src='http://image.tmdb.org/t/p/w185/".$myData['results'][$i]['poster_path']."' alt='Image' style='width:100%'><div class='card-body'><h4 class='card-title'>".$myData['results'][$i]['title']."</h4><a onClick='showFullMovie(".$myData['results'][$i]['id'].")' class='btn btn-primary'>See More</a></div></div></div><br>";

		}

		echo $searchData;

		    		?>
		   		</div>
		<!-- end of Col-md-8 --> 
		</div>


</div>
</div>
<!-- end container class -->
    <div style="height: 20px"></div>
<!-- footer -->
	<div class="jumbotron text-center" style="margin-bottom:0">
  <h4>Footer</h4>
</div>

	<script type="text/javascript">
		
function showMovieCart(id,e){
	console.log(id);
	$(".menuClass").removeClass("menuActive");
	$(e).addClass("menuActive");
    $.ajax({
            type: "POST",
            url: 'query.php',
			async: false,
            data: {
                "MOVIEID"        		: id,
                "METHOD"				: "GET_MOVIE_DETAILS"
            }
        })
        .done(function(data) {
        	console.log(data);
        	$('#movieCart').html(data); 
        })
        .fail(function(data) {
			
        })
        .always(function() {

        });		
		
}

		
function showFullMovie(id){
    $.ajax({
            type: "POST",
            url: 'query.php',
			async: false,
            data: {
                "MOVIEID"        		: id,
                "METHOD"				: "GET_FULL_MOVIE_DETAILS"
            }
        })
        .done(function(data) {
        	//console.log(data);
        	$('#movieCart').html(data); 
        })
        .fail(function(data) {
			
        })
        .always(function() {

        });		
		
}

function searchInfo(){
	var search = $("#searchMovie").val();
	//alert(search);
    $.ajax({
            type: "POST",
            url: 'query.php',
			async: false,
            data: {
                "MOVIEID"        		: search,
                "METHOD"				: "SEARCH_MOVIE_DETAILS"
            }
        })
        .done(function(data) {
        	console.log(data);
        	$('#movieCart').html(data); 
        })
        .fail(function(data) {
			
        })
        .always(function() {

        });		
		
}

	</script>



</body>
</html>