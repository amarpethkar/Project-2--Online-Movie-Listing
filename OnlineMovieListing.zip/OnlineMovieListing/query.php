<?php 
ob_start();
include_once('auth.php');

$adminMethod = $_REQUEST['METHOD'];


// get movie by genre
if($adminMethod == "GET_MOVIE_DETAILS"){
$id = $_REQUEST['MOVIEID'];
//$url = "https://api.themoviedb.org/3/movie/".$id."?api_key=fb28c6f143c808498e0f67cbb3d3caea&language=en-US";

$url = "https://api.themoviedb.org/3/discover/movie?api_key=fb28c6f143c808498e0f67cbb3d3caea&with_genres=".$id;

$ch = curl_init($url);
// var_dump($ch);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$result = curl_exec($ch);
$myData = json_decode($result,true);

// print_r($myData);


for($i=0;$i<count($myData);$i++){
//echo $i;
$searchData .= "<div class='col-sm-6' style='margin-bottom:30px'><div class='card' style='width:100%''><img class='card-img-top' src='http://image.tmdb.org/t/p/w185/".$myData['results'][$i]['poster_path']."' alt='Image' style='width:100%'><div class='card-body'><h4 class='card-title'>".$myData['results'][$i]['title']."</h4><a onClick='showFullMovie(".$myData['results'][$i]['id'].")' class='btn btn-primary'>See More</a></div></div></div><br>";

}

echo $searchData;

curl_close($ch);
}


// 
if($adminMethod == "GET_FULL_MOVIE_DETAILS"){
$id = $_REQUEST['MOVIEID'];
$url = "https://api.themoviedb.org/3/movie/".$id."?api_key=fb28c6f143c808498e0f67cbb3d3caea&language=en-US";

$ch = curl_init($url);
// var_dump($ch);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$result = curl_exec($ch);
$myData = json_decode($result,true);



$searchData = "<div class='col-sm-12'>";

$searchData.= "<div class='card'><img class='card-img-top' height='350px' style='width:300px;' src='http://image.tmdb.org/t/p/w185/".$myData['poster_path']."' alt='Image'><div class='card-body'><h4 class='card-title'>".$myData['original_title']."</h4><p class='card-text'><span><b>Genre:</b></span>&nbsp; ".$myData['genres'][0]['name']."</p><p class='card-text'><span><b>Overview:</b></span>&nbsp; ".$myData['overview']."</p><p class='card-text'><span><b>Production Company:</b></span>&nbsp; ".$myData['production_companies'][0]['name']."</p><p class='card-text'><span><b>Release Date:</b></span>&nbsp; ".$myData['release_date']."</p></div></div></div>";

echo $searchData;

curl_close($ch);
}



// search movie by name
if($adminMethod == "SEARCH_MOVIE_DETAILS"){
$id = $_REQUEST['MOVIEID'];
//echo $id;

$url = "https://api.themoviedb.org/3/search/movie?api_key=fb28c6f143c808498e0f67cbb3d3caea&query=".$id;
$url = str_replace(' ','%20',$url);

$ch = curl_init($url);
// var_dump($ch);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

$result = curl_exec($ch);
$myData = json_decode($result,true);

if($myData['total_results'] == 0){
echo "<div class='col-sm-12'><p>Data not found.</p></div>";
}else{
$searchData = "<div class='col-sm-12'>";

$searchData.= "<div class='card'><img class='card-img-top' height='350px' style='width:300px;' src='http://image.tmdb.org/t/p/w185/".$myData['results'][0]['poster_path']."' alt='Image'><div class='card-body'><h4 class='card-title'>".$myData['results'][0]['title']."</h4><a onClick='showFullMovie(".$myData['results'][0]['id'].")' class='btn btn-primary'>See More</a></div></div></div>";

echo $searchData;
}
curl_close($ch);
}

?>