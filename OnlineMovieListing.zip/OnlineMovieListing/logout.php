<?php
session_start();
//Unset the variables stored in session
unset($_SESSION['SESS_USER_NAME']);
unset($_SESSION['SESS_USER_EMAIL']);
unset($_SESSION['SESS_USER_ID']);
unset($_SESSION['SESS_USER_TYPE']);
header("location: index.php?status=4");
exit();
?>
