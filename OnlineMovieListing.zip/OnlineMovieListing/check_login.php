<?php

require_once('classes/conn_obj.php');
include_once('classes/query_class.php');
$qc = new queryClass();
include_once('classes/login_query.php');
$login = new loginModule();
//echo "login";

error_reporting(E_ALL ^ E_NOTICE);

$username = $qc->clean($_REQUEST['username']);
$password = $qc->clean($_REQUEST['password']);

//echo $username;
//echo $password;

 // Check login 
if($username!='' && $password!=''){

$valid_login_data = $login->getLoginInfo($username,$password);
//echo $valid_login_data." ".$username." ".$password;

	if($valid_login_data == true){		
		
		header("location: home.php");
		exit();
		
		}
	
	else {
	//Login failed
	//echo "error in login";
 header("location: index.php?status=1");
	exit();
	}
}

// Regrister new username

$fname = $qc->clean($_REQUEST['fname']);
$lname = $qc->clean($_REQUEST['lname']);
$email = $qc->clean($_REQUEST['email']);
$password = $qc->clean($_REQUEST['password']);

// echo $fname ." ,".$lname." , ". $email." , ". $password;

if($fname!='' && $lname!='' && $email!='' && $password!=''){
	$register_user = $qc->registerNewUser($fname,$lname,$email,$password);

	if($register_user == true){		
		header("location: index.php");
		exit();
		}else{
	//Login failed
	//echo "error in login";
 header("location: index.php?status=2");
	exit();
	}

}

?>