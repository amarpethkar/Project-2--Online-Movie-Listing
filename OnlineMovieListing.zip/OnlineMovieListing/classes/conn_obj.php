<?php

error_reporting(E_ALL ^ E_NOTICE);

$con=mysqli_connect("localhost","root","","inm");



// Check connection

if (mysqli_connect_errno())

{

echo "Failed to connect to MySQL: " . mysqli_connect_error();

}



?>