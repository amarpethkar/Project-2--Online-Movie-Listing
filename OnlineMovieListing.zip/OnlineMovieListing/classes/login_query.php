<?php
require_once('conn_obj.php');

class loginModule{

	function getLoginInfo($username,$password){
		//$password = md5($pass);
		global $con;
		try{			
			$check_admin = mysqli_query($con,"SELECT * FROM inm_admin WHERE email_id ='$username' AND password ='$password'") or die(mysqli_error());
			
			if(mysqli_num_rows($check_admin)>0) {
				//Login Successful
			
				$adminDetails = mysqli_fetch_assoc($check_admin);

				// print_r($adminDetails);
				// die;
				session_start();
				$_SESSION['SESS_USER_NAME'] = $adminDetails['first_name'].' '.$adminDetails['last_name'];
				$_SESSION['SESS_USER_EMAIL'] = $username;
				$_SESSION['SESS_DATE'] = $adminDetails['last_login'];	
				$_SESSION['SESS_USER_ID'] = $adminDetails['admin_id'];
				$_SESSION['SESS_USER_TYPE'] = "admin";
				
				$sql_log =  mysqli_query($con,"UPDATE inm_admin SET last_login=NOW() WHERE email_id = '$username'") or die(mysqli_error());		
				return true;
			}
		}
		catch(Exception $e){
			echo 'Caught exception: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($check);
		mysqli_close($con);
		//$Connect->close();
		//}
	}

	
}

?>