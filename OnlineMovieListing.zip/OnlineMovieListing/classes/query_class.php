<?php 
require_once('conn_obj.php');

class queryClass{
	
	//Function to sanitize values received from the form. Prevents SQL injection
	function clean($str){
	global $con;
		$str = @trim($str);
		if(get_magic_quotes_gpc()) {
			$str = stripslashes($str);
		}
		return mysqli_real_escape_string($con,$str);
	} // function end

	function genreList(){

			$url = "https://api.themoviedb.org/3/genre/movie/list?api_key=fb28c6f143c808498e0f67cbb3d3caea&language=en-US";

			$ch = curl_init($url);
			// var_dump($ch);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
			$result = curl_exec($ch);
			$myData = json_decode($result,true);

			//print_r(json_decode(json_encode($myData['genres'],true),true));
			// print_r($myData['genres'][0]);
			$myData = json_decode(json_encode($myData['genres'],true),true);
			// for($i=0;$i<count($myData);$i++){
			// echo $i;
			// echo $myData[$i]['name'];
			// echo '<br>';
			// }

			/*echo "curl error".curl_error($ch);*/
			return $myData; 
			curl_close($ch);

	}

	function movieList($id){

			$url = "https://api.themoviedb.org/3/discover/movie?api_key=fb28c6f143c808498e0f67cbb3d3caea&with_genres=".$id;


			$ch = curl_init($url);
			// var_dump($ch);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
			$result = curl_exec($ch);
			$myData = json_decode($result,true);

			return($myData);

			/*echo "curl error".curl_error($ch);*/

			curl_close($ch);
	}


	// register new user
	function registerNewUser($fname,$lname,$email,$password){
		global $con;
		try{
			$sql = "INSERT INTO inm_admin(first_name,last_name,email_id,password,added_date) VALUES ('$fname','$lname','$email','$password',NOW())";
			$rs_sub = mysqli_query($con,$sql) or die(mysqli_error($con));
			
			if($rs_sub){			
				return true;	
			}
			else{
				return false;
			}
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs_sub);		
		mysqli_close($con);
	
}// function end 


}