<?php 
error_reporting(E_ALL ^ E_NOTICE);
$status = $_REQUEST['status'];
//echo $status;
if($status=='' || $status==NULL){}
else { if($status==1){ ?>
              <h2>
                 Please try again with Correct Username &amp; Password.
            </h2>
              <?php } if($status==2){ ?>
             <h2>
                Process Failed, something went wrong. Please try again or contact Administrator.
             </h2>
              <?php } if($status==3){ ?>
             <h2>
                Access Denied, Please login again.
            </h2>
              <?php } if($status==5){ ?>
            <h2>
                The Validation code does not match!
             </h2>
              <?php } if($status==4){ ?>
            <h2>
                Logged out successfully.
           </h2>
              <?php } } ?>